﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace UniversityAssigment
{
     class UpdateStudent
    {

        private string connstring = ConfigurationManager.ConnectionStrings["TESTOB"].ConnectionString;


        public string UpdateRecord(Student s)
        {
            string msg = "";
            SqlConnection conn = new SqlConnection(connstring);
            try
            {
                SqlCommand cmd = new SqlCommand("UpdateStudent", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@st_id", SqlDbType.Int).Value = s.s_id;
                cmd.Parameters.Add("@st_name", SqlDbType.NVarChar, 30).Value = s.s_name;
                cmd.Parameters.Add("@st_fname", SqlDbType.NVarChar, 30).Value = s.s_fname;
                cmd.Parameters.Add("@st_gender", SqlDbType.NVarChar, 6).Value = s.s_Gender;
                cmd.Parameters.Add("@st_address", SqlDbType.NVarChar, 60).Value = s.s_address;
                cmd.Parameters.Add("@st_Course", SqlDbType.NVarChar, 60).Value = s.s_Course;
                conn.Open();
                cmd.ExecuteNonQuery();

                msg = "Data SuccessFully Updated !";
            }
            catch (Exception)
            {
                msg = "Data is Not Updated !";
            }
            finally
            {
                conn.Close();
            }
            return msg;
        }
    }
}
