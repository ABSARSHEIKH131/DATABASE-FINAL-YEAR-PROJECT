﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityAssigment
{
    class Student
    {
        public int s_id { get; set; }
        public string s_name { get; set; }
        public string s_fname { get; set; }
        public string s_Gender { get; set; }

        public string s_address { get; set; }
        public string s_fk { get; set; }

        public string s_registrDate { get; set; }

        public string s_Course {  get; set; }
    }
}
