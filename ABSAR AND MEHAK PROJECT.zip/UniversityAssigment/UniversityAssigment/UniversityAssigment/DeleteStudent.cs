﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace UniversityAssigment
{
     class DeleteStudent
    {
        private string connstring = ConfigurationManager.ConnectionStrings["TESTOB"].ConnectionString;

        public string DeleteRecord(String id)
        {
            string msg = "";
            SqlConnection conn = new SqlConnection(connstring);
            try
            {
                SqlCommand cmd = new SqlCommand("DELETEStudent", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@st_id", SqlDbType.Int).Value = id;
               
                conn.Open();
                cmd.ExecuteNonQuery();

                msg = "Data Successfully Deleted !";
            }
            catch (Exception)
            {
                msg = "Data is not Deleted";
            }
            finally
            {
                conn.Close();
            }
            return msg;
        }
    }
}
