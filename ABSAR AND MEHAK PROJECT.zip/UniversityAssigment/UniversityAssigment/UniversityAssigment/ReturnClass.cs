﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;

namespace UniversityAssigment
{
    class ReturnClass
    {
        private string connstring = ConfigurationManager.ConnectionStrings["TESTOB"].ConnectionString;
        public string scalarReturn(string q)
        {
            SqlConnection conn = new SqlConnection(connstring);
            conn.Open();
            SqlCommand cmd = new SqlCommand(q, conn);
            string s = cmd.ExecuteScalar().ToString();
            return s;
        }
    }
}
