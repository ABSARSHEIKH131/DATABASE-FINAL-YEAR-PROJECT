﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityAssigment
{
    public partial class Form1 : Form
    {
        public static string fk_ad;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = usertxt.Text;
            string password = passtxt.Text;
            string userdb, passworddb;

            ReturnClass rc = new ReturnClass();
            userdb = rc.scalarReturn("select count(ad_id) from administator where ad_name ='" + user + "' ");

            if(userdb.Equals("0"))
            {
                MessageBox.Show("Invalid UserName");
            }
            else
            {
                passworddb = rc.scalarReturn("select ad_password from administator where ad_name = '" + user + "'");

                if(passworddb.Equals(password)) 
                {
                  fk_ad=  rc.scalarReturn("select ad_id from administator where ad_name = '" + user + "'");
                 Form2 f2 = new Form2();
                    f2.Show();
                }
                else
                {
                    MessageBox.Show("Invalid Password");
                }
            }
        }
    }
}
