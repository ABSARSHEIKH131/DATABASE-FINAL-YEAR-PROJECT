﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityAssigment
{
    public partial class Delete : Form
    {
        public Delete()
        {
            InitializeComponent();
        }
        private string connstring = ConfigurationManager.ConnectionStrings["TESTOB"].ConnectionString;

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            nametxt.Text = " ";
            fnametxt.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            addresstxt.Text = " ";





            SqlConnection connection = new SqlConnection(connstring);
            string sql = "select s.st_name,s.st_fname,s.st_gender,s.st_address , s.st_Course from Student s where s.st_id=" + textBox1.Text;

            try
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand(sql, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    nametxt.Text = reader.GetValue(0).ToString();
                    fnametxt.Text = reader.GetValue(1).ToString();
                    if (reader.GetValue(2).ToString().Equals("male"))
                    {
                        radioButton1.Checked = true;
                    }
                    else
                    {
                        radioButton2.Checked = true;
                    }
                    addresstxt.Text = reader.GetValue(3).ToString();
                    coursetxt.Text = reader.GetValue(4).ToString();
                }

                
            }

            catch (Exception)
            {
               
            }
            finally
            {
                connection.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DeleteStudent ds = new DeleteStudent();
           string msg= ds.DeleteRecord(textBox1.Text);
            MessageBox.Show(msg);
            textBox1.Text = "";
            nametxt.Text = "";
            fnametxt.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            addresstxt.Text = " ";
            coursetxt.Text = " ";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            DeleteStudent ds = new DeleteStudent();
            string msg = ds.DeleteRecord(textBox1.Text);
            MessageBox.Show(msg);
            textBox1.Text = "";
            nametxt.Text = "";
            fnametxt.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            addresstxt.Text = " ";
            coursetxt.Text = " ";
        }

        private void Delete_Load(object sender, EventArgs e)
        {

        }
    }
}
