﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityAssigment
{
    public partial class View : Form
    {
        public View()
        {
            InitializeComponent();
        }

        private void View_Load(object sender, EventArgs e)
        {
            string q = "select s.st_id as 'Studend id' , s.st_name as 'Student Name', s.st_fname as 'Father Name', s.st_gender as 'Gender', s.st_address as 'Address', s.st_admisiondate as 'Admission Date', s.st_Course as 'Course'  from Student s";
            Student_View v = new Student_View(q);
            dataGridView1.DataSource = v.showrecord();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string q = "select s.st_id as 'Student id' , s.st_name as 'Student Name', s.st_fname as 'Father Name', s.st_gender as 'Gender', s.st_address as 'Address', s.st_admisiondate as 'Admission Date',  s.st_Course as 'Course'  from Student s where s.st_name like '" + textBox1.Text+"%'";
            Student_View v = new Student_View(q);
            dataGridView1.DataSource = v.showrecord();
        }
    }
}
