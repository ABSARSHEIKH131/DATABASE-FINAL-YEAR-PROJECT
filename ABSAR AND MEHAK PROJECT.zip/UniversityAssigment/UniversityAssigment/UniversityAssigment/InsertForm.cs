﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityAssigment
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.s_fk = Form1.fk_ad;
            s.s_registrDate= System.DateTime.Now.ToShortDateString();
            s.s_name = nametxt.Text;
            s.s_fname = fnametxt.Text;
            s.s_address = addresstxt.Text;   
            s.s_Course = coursetxt.Text;
            if (radioButton1.Checked==true)
            {
                s.s_Gender = "male";
            }
            else if (radioButton2.Checked==true)
            {
                s.s_Gender = "female";
            }
            else
            {
                MessageBox.Show("Please Select Gender");
            }

            insert i = new insert();
           MessageBox.Show( i.InsertRecord(s));
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void addresstxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void fnametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void lable4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void nametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.s_fk = Form1.fk_ad;
            s.s_registrDate = System.DateTime.Now.ToShortDateString();
            s.s_name = nametxt.Text;
            s.s_fname = fnametxt.Text;
            s.s_address = addresstxt.Text;
            s.s_Course = coursetxt.Text;
            if (radioButton1.Checked == true)
            {
                s.s_Gender = "male";
            }
            else if (radioButton2.Checked == true)
            {
                s.s_Gender = "female";
            }
            else
            {
                MessageBox.Show("Please Select Gender");
            }

            insert i = new insert();
            MessageBox.Show(i.InsertRecord(s));
        }

        private void InsertForm_Load(object sender, EventArgs e)
        {

        }
    }
}
