﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace UniversityAssigment
{
    class insert
    {
        private string connstring = ConfigurationManager.ConnectionStrings["TESTOB"].ConnectionString;

        public string InsertRecord(Student s)
        {
            string msg = "";
            SqlConnection conn = new SqlConnection(connstring);
            try
            {
                SqlCommand cmd = new SqlCommand("insertStudent",conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@st_name", SqlDbType.NVarChar, 30).Value = s.s_name;
                cmd.Parameters.Add("@st_fname", SqlDbType.NVarChar, 30).Value = s.s_fname;
                cmd.Parameters.Add("@st_gender", SqlDbType.NVarChar, 6).Value = s.s_Gender;
                cmd.Parameters.Add("@st_address", SqlDbType.NVarChar, 60).Value = s.s_address;
                cmd.Parameters.Add("@st_admisiondate", SqlDbType.NVarChar, 30).Value = s.s_registrDate;
                cmd.Parameters.Add("@st_AdministatorId", SqlDbType.NVarChar, 30).Value = s.s_fk;
                cmd.Parameters.Add("@st_Course", SqlDbType.NVarChar, 40).Value = s.s_Course;
                conn.Open();
                cmd.ExecuteNonQuery();

                msg = "Data SuccessFully Save !";
            }
            catch (Exception ) 
            {
                msg = "Data is not Save ! Please Contack With Absar Ali";
            }
            finally 
            { 
                conn.Close(); 
            }
            return msg;
        }
    }
}
