﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniversityAssigment
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Update update = new Update();
            update.Show();
            Form2 form = new Form2();
            form.Close();
            form.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            InsertForm obj = new InsertForm();
            obj.Show();
            Form2 form = new Form2();
            form.Close();
            form.Hide();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Delete d = new Delete();
            d.Show();
            
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            View view = new View();
            view.Show();
            
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Close();
        }
    }
}
